/**
 * A program that will take in several PPM files as input, and return an averages of those files.
 * this program contains three functions readPPM, averagePPM, and writePPM. This program also contains
 * two structs: PPMPixel and PPMFile.
 * @author Ben Johnson
 * @version 1.0
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/**
 * PPMPixel: A struct containg the data for one pixel, with the red, green, and blue values being represented as integers.
 */

struct PPMPixel
{
    int red;
    int green;
    int blue;
};


/**
 * PPMFile: A struct containg the data for one PPPM file
 */
struct PPMFile
{
    char *type;     //a char array for the file type
    int width;      // an int for image width
    int height;     // an int for image height
    int max;        // an int for image's max color value
    struct PPMPixel *pixels;    //an array of PPMPixel structs
};


/**
 * readPPM: A function that takes in a PPM file name, and returns a PPMFile of the data within the image
 * @param char* fileName
 */
struct PPMFile readPPM(char* fileName)
{
    char *fileType = malloc(sizeof(*fileType));
    int cols;
    int rows;
    int colorMax;
    struct PPMFile image;


    //Open PPM files, and assign basic data to variables
    FILE* file_ptr;

    file_ptr = fopen(fileName, "r");
    fscanf(file_ptr, "%s", fileType);
    fscanf(file_ptr, "%d%d", &cols, &rows);
    fscanf(file_ptr, "%d", &colorMax);

    //Itterate through PPM file, assign color values to a PPMPixel, and add that pixel to data
    int size = (cols * rows);
    struct PPMPixel *data = malloc(cols * rows * sizeof(struct PPMPixel));

    for (int i = 0; i < size; i++) {
        struct PPMPixel* pixel = malloc(sizeof(*pixel));
        fscanf(file_ptr, " %d", &pixel->red);
        fscanf(file_ptr, " %d", &pixel->green);
        fscanf(file_ptr, " %d", &pixel->blue);
        data[i] = *pixel;
        free(pixel);
    }

    //Close file
    fclose(file_ptr);

    //Assign variales to PPMFile struct, and return PPMFile
    image.type = fileType;
    image.width = cols;
    image.height = rows;
    image.max = colorMax;
    image.pixels = data;

    return image;

}


/**
 * averagePPM: A function that asks the user to input several PPM images, and returns an average PPMFile
 */
struct PPMFile averagePPM()
{
    int numFiles;
    int avgWidth;
    int avgHeight;
    int avgColorMax;

    struct PPMFile averageImage;

    printf("%s", "Enter the number of PPM Files you would like to average: ");
    scanf("%d", &numFiles);
    printf("%s", "Enter the width of the averaged PPM File: ");
    scanf("%d", &avgWidth);
    printf("%s", "Enter the height of the averaged PPM File: ");
    scanf("%d", &avgHeight);
    printf("%s", "Enter the max color value of the averaged PPM File: ");
    scanf("%d", &avgColorMax);

    //Create array of PPMFiles, and add user inputted files to this array
    struct PPMFile *files = malloc(numFiles * sizeof(struct PPMFile));

    for (int i = 0; i < numFiles; i++) {
        char* fileName = malloc(sizeof(*fileName));
        printf("%s%d%s", "Enter the file number ", i + 1, ": ");
        scanf("%s", fileName);
        struct PPMFile image;

        image = readPPM(fileName);

        files[i] = image;
        free(fileName);

        printf("%s", "File Added!\n");
    }

    //Create array of PPMPixel, and sum the total of each inputted PPMFiles pixel data to this array
    struct PPMPixel *data = malloc(avgWidth * avgHeight * sizeof(struct PPMPixel));

    for (int i = 0; i < numFiles; i++) {
        for (int k = 0; k < (avgWidth * avgHeight); ++k) {
            data[k].red += files[i].pixels[k].red;
            data[k].green += files[i].pixels[k].green;
            data[k].blue += files[i].pixels[k].blue;
        }
    }

    averageImage.type = "P3";
    averageImage.width = avgWidth;
    averageImage.height = avgHeight;
    averageImage.max = avgColorMax;

    //Divide the color value in each PPMPixel by the number of files to get an average
    for (int i = 0; i < (averageImage.width * averageImage.height); ++i) {
        data[i].red = (data[i].red / numFiles);
        data[i].green = (data[i].green / numFiles);
        data[i].blue = (data[i].blue / numFiles);

    }

    //Add this average pixel data to the PPMFile and return it
    averageImage.pixels = data;

    return averageImage;

}


/**
 * readPPM: A function that takes in a PPMFile and a char array, and writes the PPMFile's data to file
 * @param struct PPMFile image
 * @param char* fileName
 */
void writePPM(struct PPMFile image, char* fileName)
{

    //Open a file using the file name
    FILE* outputFile = fopen(fileName, "w");

    //Write the PPMFile data to the tile
    fprintf(outputFile, "%s\n", image.type);
    fprintf(outputFile, "%d %d\n", image.width, image.height);
    fprintf(outputFile, "%d\n", image.max);
    for(int i = 0; i < (image.width * image.height); ++i) {
        fprintf(outputFile, "%d %d %d \n", (image.pixels[i].red), (image.pixels[i].green), (image.pixels[i].blue));
    }

    //Close the file
    fclose(outputFile);

}

int main()
{
    struct PPMFile image = averagePPM();
    writePPM(image, "average.ppm");

}
